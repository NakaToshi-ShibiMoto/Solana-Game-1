import React from 'react'
import { render } from 'react-dom'

function StackIt () {
    return(
        <div>
            Stack
        </div>
    )
}

export default StackIt;